package student_api.service;

import java.util.List;

import org.springframework.stereotype.Service;

import student_api.entity.Student;
import student_api.repository.StudentRepository;

@Service
public class StudentService {

    private final StudentRepository repo;

    public StudentService(StudentRepository repo) {
        this.repo = repo;
    }

    // Get all students
    public List<Student> getAll() {
        return repo.findAll();
    }

    // Get student by ID
    public Student getById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found"));
    }

    // Create student
    public Student create(Student student) {
        return repo.save(student);
    }

    // Update student
    public Student update(Long id, Student student) {

        Student existing = getById(id);

        existing.setFirstName(student.getFirstName());
        existing.setLastName(student.getLastName());
        existing.setEmail(student.getEmail());
        existing.setDepartment(student.getDepartment());
        existing.setYear(student.getYear());
        existing.setGpa(student.getGpa());

        return repo.save(existing);
    }

    // Delete student
    public void delete(Long id) {
        repo.deleteById(id);
    }
}