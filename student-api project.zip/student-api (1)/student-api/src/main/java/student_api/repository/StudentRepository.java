package student_api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import student_api.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {

    Student findByRollNumber(String rollNumber);
}